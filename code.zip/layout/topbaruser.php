 <header class="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#283339] px-10 py-3">
          <div class="flex items-center gap-8">
            <div class="flex items-center gap-4 text-white">
              <div class="size-4">
              </div>
              <h2 class="text-white text-lg font-bold leading-tight tracking-[-0.015em]">TumbasBuku</h2>
            </div>
            <div class="flex items-center gap-9">
              <a class="text-white text-sm font-medium leading-normal" href="index.php">Beranda</a>
              <a class="text-white text-sm font-medium leading-normal" href="kategori.php">Kategori Buku</a>
              <a class="text-white text-sm font-medium leading-normal" href="penulis.php">Penulis</a>
              <a class="text-white text-sm font-medium leading-normal" href="kontakadmin.php">Kontak Admin</a>
              <a class="text-white text-sm font-medium leading-normal" href="userorders.php">Riwayat Transaksi</a>
              <div>
            <a class="text-red-600 text-sm font-medium leading-normal hover:text-red-400 transition-colors" href="../logout.php">Log Out</a>

</div>

            </div>
                </div>
                
            </label>
            <div class="flex gap-2">
              <button class="flex items-center justify-center overflow-hidden rounded-lg h-10 bg-[#283339] text-white gap-2 text-sm font-bold leading-normal px-2.5">
                <div class="text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" fill="currentColor" viewBox="0 0 256 256">
                    <path
                      d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,160H40V56H216V200ZM176,88a48,48,0,0,1-96,0,8,8,0,0,1,16,0,32,32,0,0,0,64,0,8,8,0,0,1,16,0Z"
                    ></path>
                  </svg>
                </div>
              </button>
            </div>
            <div
              class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10"
              style='background-image: url("https://static.vecteezy.com/system/resources/previews/005/005/788/non_2x/user-icon-in-trendy-flat-style-isolated-on-grey-background-user-symbol-for-your-web-site-design-logo-app-ui-illustration-eps10-free-vector.jpg");'
            ></div>
          </div>
        </header>
