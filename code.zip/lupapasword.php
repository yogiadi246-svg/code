<?php
// forgot_password.php

// Pastikan file koneksi tersedia dan koneksi disimpan di $conn
include 'koneksi.php'; 
session_start();

// Aktifkan pelaporan error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inisialisasi variabel
$message = ""; 
$email = '';
$show_popup = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    
    if (empty($email)) {
        $message = "Alamat email wajib diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Format email tidak valid.";
    } else {
        // 1. Cek apakah Email ada di database
        $sql = "SELECT id FROM users WHERE email = ?";
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            
            if (mysqli_stmt_num_rows($stmt) > 0) {
                // Email ditemukan. Lanjutkan ke simulasi pengiriman kode.
                
                // 2. Simulasi pembuatan kode reset (6 digit random)
                $reset_code = str_pad(rand(1, 999999), 6, '0', STR_PAD_LEFT);
                
                // 3. Simpan kode dan email ke session (Simulasi token/reset link)
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_code'] = $reset_code; // Kode yang akan ditampilkan di popup

                // 4. Set flag untuk menampilkan popup
                $show_popup = true;
            } else {
                $message = "Email tidak terdaftar dalam sistem kami.";
            }
            mysqli_stmt_close($stmt);
        } else {
            $message = "Error database. Silakan coba lagi.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />

    <title>TumbasBuku | Forgot Password</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <style>
      /* Memastikan form input tetap gelap */
      .form-input {
        background-color: #283339 !important; 
        color: #fff !important; 
        border: none !important;
      }
      .form-input:focus {
        border-color: #1193d4 !important; 
        box-shadow: 0 0 0 1px #1193d4 !important;
      }
      /* Style untuk Modal */
      .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.75);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
      }
      .modal-content {
        background-color: #111618;
        padding: 2rem;
        border-radius: 0.5rem;
        width: 90%;
        max-width: 400px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      }
    </style>

    <?php
 include "layout/topbar.php";
?>
        
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 flex-1 items-center">
            <h2 class="text-white tracking-light text-[28px] font-bold leading-tight px-4 text-center pb-3 pt-5">Forgot your password?</h2>
            <p class="text-white text-base font-normal leading-normal pb-3 pt-1 px-4 text-center">
              Enter the email address associated with your account and we'll send you a link to reset your password.
            </p>

            <?php if ($message): ?>
                <p class="text-red-500 text-sm font-medium leading-normal pb-3 pt-1 px-4 text-center">
                    <?php echo htmlspecialchars($message); ?>
                </p>
            <?php endif; ?>
            
            <form method="POST" action="" class="w-full max-w-[480px]">
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <input
                            type="email"
                            name="email"
                            placeholder="Email Address"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 h-14 placeholder:text-[#9db0b9] p-4 text-base font-normal leading-normal"
                            value="<?= htmlspecialchars($email) ?>"
                            required
                        />
                    </label>
                </div>
                <div class="flex px-4 py-3 justify-center">
                    <button
                        type="submit"
                        class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#1193d4] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#0e7abf] transition-colors"
                    >
                        <span class="truncate">Send Reset Link</span>
                    </button>
                </div>
            </form>
            
          </div>
        </div>
      </div>
    </div>
    
    <div id="resetModal" class="modal-overlay hidden">
        <div class="modal-content">
            <h3 class="text-white text-xl font-bold mb-4">Kode Reset Password</h3>
            <p class="text-white text-base mb-4">Simulasi: Kode telah "dikirim" ke **<?= htmlspecialchars($_SESSION['reset_email'] ?? 'email Anda') ?>**. Kode reset Anda adalah:</p>
            
            <div class="text-center bg-[#283339] text-white text-3xl font-mono py-4 rounded-lg mb-6">
                <span id="resetCodeDisplay"><?= htmlspecialchars($_SESSION['reset_code'] ?? '******') ?></span>
            </div>

            <p class="text-gray-400 text-sm mb-6">Catatan: Karena ini adalah simulasi, kode ditampilkan di sini. Dalam aplikasi nyata, Anda akan memeriksa inbox email Anda.</p>

            <a href="pembaruanpassword.php" 
                class="flex min-w-full max-w-full cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#1193d4] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#0e7abf] transition-colors">
                Lanjut ke Pembaruan Password
            </a>
        </div>
    </div>

    <script>
        <?php if ($show_popup): ?>
            document.getElementById('resetModal').classList.remove('hidden');
        <?php endif; ?>
    </script>
  </body>
</html>