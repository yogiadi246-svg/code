<?php
// register.php

// Sertakan koneksi ke database
include 'koneksi.php'; 
session_start(); // Tambahkan session_start() jika belum ada dan jika diperlukan untuk pesan sukses

// Aktifkan pelaporan error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inisialisasi variabel
$message = ""; 
$username = '';
$email = '';
$password = ''; 
$location = ''; // Variabel diubah dari $full_name menjadi $location
$phone_number = ''; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Ambil data dari form: KOREKSI NAMA VARIABEL POST
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    // AMBIL DARI name="location"
    $location = trim($_POST['location'] ?? ''); 
    // AMBIL DARI name="phone_number"
    $phone_number = trim($_POST['phone_number'] ?? ''); 

    // 2. Validasi input dasar
    // Validasi kolom 'Lokasi' menggunakan variabel $location
    if (empty($username) || empty($email) || empty($password) || empty($location)) {
        $message = "Semua kolom (Username, Email, Password, Lokasi) wajib diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Format email tidak valid.";
    } elseif (strlen($password) < 6) {
        $message = "Password minimal 6 karakter.";
    } else {
        // 3. Hashing Password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        // 4. Cek apakah Email atau Username sudah terdaftar
        $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
        if ($stmt_check = mysqli_prepare($conn, $check_sql)) {
            mysqli_stmt_bind_param($stmt_check, "ss", $username, $email);
            mysqli_stmt_execute($stmt_check);
            mysqli_stmt_store_result($stmt_check);
            
            if (mysqli_stmt_num_rows($stmt_check) > 0) {
                $message = "Username atau Email sudah terdaftar.";
            } else {
                // 5. Masukkan data ke database: KOREKSI NAMA KOLOM
                // Menggunakan kolom 'password', 'no_hp', dan 'lokasi' yang ada di tabel 'users'.
                // Kolom 'alamat' diabaikan karena hanya ada satu input lokasi di form.
                $insert_sql = "INSERT INTO users (username, email, password, no_hp, lokasi, role) VALUES (?, ?, ?, ?, ?, 'user')";
                
                if ($stmt_insert = mysqli_prepare($conn, $insert_sql)) {
                    // Tipe data: string, string, string (hash), string (no_hp), string (lokasi)
                    mysqli_stmt_bind_param($stmt_insert, "sssss", $username, $email, $password_hash, $phone_number, $location);
                    
                    if (mysqli_stmt_execute($stmt_insert)) {
                        header("Location: login.php?status=success");
                        exit;
                    } else {
                        $message = "Registrasi gagal: " . mysqli_error($conn);
                    }
                    mysqli_stmt_close($stmt_insert);
                } else {
                    $message = "Error database saat menyiapkan query insert.";
                }
            }
            mysqli_stmt_close($stmt_check);
        } else {
            $message = "Error database saat menyiapkan query check.";
        }
    }
}

if (isset($_GET['status']) && $_GET['status'] == 'success') {
    $message = "Registrasi berhasil! Silakan login.";
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />

    <title>TumbasBuku | Register User</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <style>
      /* --- PERBAIKAN CSS UNTUK TEXTBOX PUTIH --- */
      .form-input {
        /* Memastikan latar belakang tetap gelap */
        background-color: #1c2327 !important; 
        /* Memastikan warna teks tetap putih */
        color: #fff !important; 
        /* Memastikan border tetap sesuai design */
        border: 1px solid #3b4b54 !important;
      }
      /* Memperbaiki fokus pada input agar sesuai dengan design */
      .form-input:focus {
        border-color: #1193d4 !important; 
        box-shadow: 0 0 0 1px #1193d4 !important;
      }
    </style>
        <?php
include "layout/topbar.php";
?>
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 flex-1 items-center">
            <h2 class="text-white tracking-light text-[28px] font-bold leading-tight px-4 text-center pb-3 pt-5">Create your account</h2>
            
            <form method="POST" action="" class="w-full max-w-[480px]">

                <?php if ($message): ?>
                    <p class="text-<?= isset($_GET['status']) && $_GET['status'] == 'success' ? 'green-400' : 'red-500' ?> text-sm font-medium leading-normal pb-3 pt-1 px-4 text-center">
                        <?php echo htmlspecialchars($message); ?>
                    </p>
                <?php endif; ?>

                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <p class="text-white text-base font-medium leading-normal pb-2">Username</p>
                        <input
                            type="text"
                            name="username"
                            placeholder="Masukkan Username"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border border-[#3b4b54] bg-[#1c2327] focus:border-[#3b4b54] h-14 placeholder:text-[#9db0b9] p-[15px] text-base font-normal leading-normal"
                            value="<?= htmlspecialchars($username) ?>"
                            required
                        />
                    </label>
                </div>

                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <p class="text-white text-base font-medium leading-normal pb-2">Email</p>
                        <input
                            type="email"
                            name="email"
                            placeholder="Masukkan Email"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border border-[#3b4b54] bg-[#1c2327] focus:border-[#3b4b54] h-14 placeholder:text-[#9db0b9] p-[15px] text-base font-normal leading-normal"
                            value="<?= htmlspecialchars($email) ?>"
                            required
                        />
                    </label>
                </div>

                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <p class="text-white text-base font-medium leading-normal pb-2">Password</p>
                        <input
                            type="password"
                            name="password"
                            placeholder="Masukkan password"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border border-[#3b4b54] bg-[#1c2327] focus:border-[#3b4b54] h-14 placeholder:text-[#9db0b9] p-[15px] text-base font-normal leading-normal"
                            required
                        />
                    </label>
                </div>

                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <p class="text-white text-base font-medium leading-normal pb-2">Lokasi (Alamat Kirim)</p>
                        <input
                            type="text"
                            name="location"
                            placeholder="Masukkan Alamat"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border border-[#3b4b54] bg-[#1c2327] focus:border-[#3b4b54] h-14 placeholder:text-[#9db0b9] p-[15px] text-base font-normal leading-normal"
                            value="<?= htmlspecialchars($location) ?>"
                            required
                        />
                    </label>
                </div>

                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <p class="text-white text-base font-medium leading-normal pb-2">No. Hp</p>
                        <input
                            type="tel"
                            name="phone_number"
                            placeholder="Masukkan Nomor Hp"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border border-[#3b4b54] bg-[#1c2327] focus:border-[#3b4b54] h-14 placeholder:text-[#9db0b9] p-[15px] text-base font-normal leading-normal"
                            value="<?= htmlspecialchars($phone_number) ?>"
                        />
                    </label>
                </div>

                <div class="flex px-4 py-3">
                    <button
                        type="submit"
                        class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 flex-1 bg-[#1193d4] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#0e7abf] transition-colors"
                    >
                        <span class="truncate">Register</span>
                    </button>
                </div>
            </form>
            
            <p class="text-[#9db0b9] text-sm font-normal leading-normal pb-3 pt-1 px-4 text-center">
                Sudah Punya Akun ?
                <a href="login.php" class="text-[#1193d4] underline hover:text-white">Login</a>
            </p>

          </div>
        </div>
      </div>
    </div>
  </body>
</html>