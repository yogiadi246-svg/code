<?php
include '../koneksi.php';
session_start();

// Pastikan variabel koneksi benar
$db = null;
if (isset($conn) && $conn instanceof mysqli) {
    $db = $conn;
} elseif (isset($koneksi) && $koneksi instanceof mysqli) {
    $db = $koneksi;
} else {
    die("Koneksi database gagal: variabel koneksi tidak ditemukan di koneksi.php");
}

// Jika parameter ?penulis= ada → tampilkan buku penulis tsb
$selected_penulis = isset($_GET['penulis']) ? $db->real_escape_string($_GET['penulis']) : null;

if ($selected_penulis) {
    // Ambil semua buku dari penulis terpilih
    $query_buku = "SELECT id, judul, penulis, url FROM buku WHERE penulis = '$selected_penulis'";
    $result_buku = $db->query($query_buku);
} else {
    // Ambil daftar penulis unik dari tabel buku
    $query_penulis = "SELECT DISTINCT penulis FROM buku ORDER BY penulis ASC";
    $result_penulis = $db->query($query_penulis);
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />

    <title>TumbasBuku | Penulis</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
                <?php include "../layout/topbaruser.php"; ?>


        <!-- KONTEN -->
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">

            <?php if ($selected_penulis): ?>
              <!-- Jika penulis dipilih -->
              <div class="flex flex-wrap justify-between gap-3 p-4">
                <p class="text-white text-[32px] font-bold leading-tight">Buku oleh <?= htmlspecialchars($selected_penulis) ?></p>
              </div>

              <div class="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3 p-4">
                <?php if ($result_buku && $result_buku->num_rows > 0): ?>
                  <?php while ($buku = $result_buku->fetch_assoc()): ?>
                    <a href="bookdetail.php?id=<?= htmlspecialchars($buku['id']); ?>" 
                       class="flex flex-1 gap-3 rounded-lg border border-[#3b4b54] bg-[#1c2327] p-4 flex-col hover:scale-[1.03] transition-transform duration-200">
                      <div class="bg-center bg-no-repeat aspect-[3/4] bg-cover rounded-lg w-full"
                           style='background-image: url("<?= htmlspecialchars($buku['url']) ?>");'></div>
                      <div class="flex flex-col gap-1">
                        <h2 class="text-white text-base font-bold leading-tight"><?= htmlspecialchars($buku['judul']) ?></h2>
                        <p class="text-[#9db0b9] text-sm font-normal leading-normal"><?= htmlspecialchars($buku['penulis']) ?></p>
                      </div>
                    </a>
                  <?php endwhile; ?>
                <?php else: ?>
                  <p class="text-gray-400 text-center w-full py-4">Belum ada buku oleh penulis ini.</p>
                <?php endif; ?>
              </div>

            <?php else: ?>
              <!-- Jika belum pilih penulis -->
              <div class="flex flex-wrap justify-between gap-3 p-4">
                <p class="text-white tracking-light text-[32px] font-bold leading-tight min-w-72">Authors</p>
              </div>

              <div class="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3 p-4">
                <?php if ($result_penulis && $result_penulis->num_rows > 0): ?>
                  <?php while ($penulis = $result_penulis->fetch_assoc()): ?>
                    <a href="penulis.php?penulis=<?= urlencode($penulis['penulis']) ?>" 
                       class="flex flex-1 gap-3 rounded-lg border border-[#3b4b54] bg-[#1c2327] p-4 flex-col hover:scale-[1.03] transition-transform duration-200">
                      <div
                        class="bg-center bg-no-repeat aspect-square bg-cover rounded-full w-10 shrink-0"
                        style='background-image: url("https://ui-avatars.com/api/?name=<?= urlencode($penulis['penulis']) ?>&background=283339&color=fff");'></div>
                      <div class="flex flex-col gap-1">
                        <h2 class="text-white text-base font-bold leading-tight"><?= htmlspecialchars($penulis['penulis']) ?></h2>
                        <p class="text-[#9db0b9] text-sm font-normal leading-normal">Klik untuk melihat buku karya <?= htmlspecialchars($penulis['penulis']) ?></p>
                      </div>
                    </a>
                  <?php endwhile; ?>
                <?php else: ?>
                  <p class="text-gray-400 text-center w-full py-4">Belum ada data penulis di database.</p>
                <?php endif; ?>
              </div>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
  </body>
</html>
