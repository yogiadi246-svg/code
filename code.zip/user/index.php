<?php
include '../koneksi.php';
session_start();

// Ambil data buku dari database
$query = "SELECT id, judul, penulis, url FROM buku ORDER BY id DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />
    <title>TumbasBuku | Home</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden" 
         style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
        <?php include "../layout/topbaruser.php"; ?>

        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">
            <div class="px-4 py-3">
                <div class="flex w-full flex-1 items-stretch rounded-lg h-full">
                  <div class="text-[#9db0b9] flex border-none bg-[#283339] items-center justify-center pl-4 rounded-l-lg border-r-0">
                    
                  </div>
                </div>
      
            </div>

            <div class="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3 p-4">
              <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <!-- Bungkus buku dalam link menuju halaman detail -->
                  <a href="bookdetail.php?id=<?= $row['id'] ?>" 
                     class="flex flex-col gap-3 pb-3 hover:scale-[1.03] transition-transform duration-200">
                    <div
                      class="w-full bg-center bg-no-repeat aspect-[3/4] bg-cover rounded-lg"
                      style='background-image: url("<?= htmlspecialchars($row['url']) ?>");'
                    ></div>
                    <div>
                      <p class="text-white text-base font-medium leading-normal">
                        <?= htmlspecialchars($row['judul']) ?>
                      </p>
                      <p class="text-[#9db0b9] text-sm font-normal leading-normal">
                        <?= htmlspecialchars($row['penulis']) ?>
                      </p>
                    </div>
                  </a>
                <?php endwhile; ?>
              <?php else: ?>
                <p class="text-center text-gray-400 py-4">Belum ada buku yang tersedia.</p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
