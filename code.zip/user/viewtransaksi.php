<?php
session_set_cookie_params(['path' => '/']);
session_start();

include 'koneksi.php';


$user_id = $_SESSION['id'];
$order_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// ==== AMBIL DATA PESANAN ====
$query_order = "
    SELECT p.*, u.nama AS nama_pemesan
    FROM pemesanan p
    JOIN users u ON p.user_id = u.id
    WHERE p.id = $order_id AND p.user_id = $user_id
";
$order_result = $koneksi->query($query_order);

if (!$order_result) {
    die('Query gagal (order): ' . $koneksi->error);
}

$order = $order_result->fetch_assoc();

if (!$order) {
    die('Pesanan tidak ditemukan atau bukan milik Anda.');
}

// ==== AMBIL DETAIL ITEM PESANAN ====
$query_items = "
    SELECT b.judul AS nama_buku, dp.jumlah, dp.harga
    FROM detail_pemesanan dp
    INNER JOIN buku b ON dp.buku_id = b.id
    WHERE dp.pemesanan_id = $order_id
";
$items = $koneksi->query($query_items);

if (!$items) {
    die('Query gagal (detail): ' . $koneksi->error);
}
?>





<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />
    <title>Stitch Design</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
        <header class="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#283339] px-10 py-3">
          <div class="flex items-center gap-4 text-white">
            <div class="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor"></path></svg>
            </div>
            <h2 class="text-white text-lg font-bold leading-tight tracking-[-0.015em]">NovelNest</h2>
          </div>
          <div class="flex flex-1 justify-end gap-8">
            <div class="flex items-center gap-9">
              <a class="text-white text-sm font-medium leading-normal" href="#">New &amp; Noteworthy</a>
              <a class="text-white text-sm font-medium leading-normal" href="#">Bestsellers</a>
              <a class="text-white text-sm font-medium leading-normal" href="#">Featured Shops</a>
              <a class="text-white text-sm font-medium leading-normal" href="#">Books</a>
              <a class="text-white text-sm font-medium leading-normal" href="#">Audiobooks</a>
              <a class="text-white text-sm font-medium leading-normal" href="#">Special Offers</a>
            </div>
            <div class="flex gap-2">
              <button class="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 bg-[#283339] text-white gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-2.5">
                <div class="text-white" data-icon="MagnifyingGlass" data-size="20px" data-weight="regular">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" fill="currentColor" viewBox="0 0 256 256">
                    <path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"></path>
                  </svg>
                </div>
              </button>
              <button class="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 bg-[#283339] text-white gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-2.5">
                <div class="text-white" data-icon="User" data-size="20px" data-weight="regular">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" fill="currentColor" viewBox="0 0 256 256">
                    <path d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"></path>
                  </svg>
                </div>
              </button>
            </div>
            <div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDHyGP_K-qMCN4lB8Ld28Uq4TL0YCfWCrU-rJcYvGXC5O9Pae0hIO1TVWmpOW06qezXJFobK6xtfy-GW8pSbiIn3TLSKUiaW-FVVy2KMfdke5gLVoDtbElW-ccZ8mJgFSgtsQopz6QW_hq40hmJifRr7Vy5L3qk_MmTdp0IDrwC3ekYBwrypK_clzIHOPo3poRtD6wGEpx7G-wg0SdyA9T61fr2yMbHVeMPbGIGAFUCOtSzblFDl6R1X5heHFHJm0u0VlfFQr3F3fk");'></div>
          </div>
        </header>
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">
            <div class="flex flex-wrap gap-2 p-4">
              <a class="text-[#9db0b9] text-base font-medium leading-normal" href="#">Orders</a>
              <span class="text-[#9db0b9] text-base font-medium leading-normal">/</span>
              <span class="text-white text-base font-medium leading-normal">Order Details</span>
            </div>
            <div class="flex flex-wrap justify-between gap-3 p-4">
              <div class="flex min-w-72 flex-col gap-3">
                <p class="text-white tracking-light text-[32px] font-bold leading-tight">Order Details</p>
                <p class="text-[#9db0b9] text-sm font-normal leading-normal">
                  Order #<?= htmlspecialchars($order['order_number'] ?? '-') ?> • Placed on <?= htmlspecialchars($order['order_date'] ?? '-') ?>
                </p>
              </div>
            </div>

            <h3 class="text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Items</h3>
            <div class="px-4 py-3 @container">
              <div class="flex overflow-hidden rounded-lg border border-[#3b4b54] bg-[#111618]">
                <table class="flex-1">
                  <thead>
                    <tr class="bg-[#1c2327]">
                      <th class="px-4 py-3 text-left text-white w-[400px] text-sm font-medium leading-normal">Item</th>
                      <th class="px-4 py-3 text-left text-white w-[400px] text-sm font-medium leading-normal">Quantity</th>
                      <th class="px-4 py-3 text-left text-white w-[400px] text-sm font-medium leading-normal">Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while ($row = $items->fetch_assoc()): ?>
                      <tr class="border-t border-t-[#3b4b54]">
                        <td class="h-[72px] px-4 py-2 w-[400px] text-white text-sm font-normal leading-normal"><?= htmlspecialchars($row['judul']) ?></td>
                        <td class="h-[72px] px-4 py-2 w-[400px] text-[#9db0b9] text-sm font-normal leading-normal"><?= htmlspecialchars($row['jumlah']) ?></td>
                        <td class="h-[72px] px-4 py-2 w-[400px] text-[#9db0b9] text-sm font-normal leading-normal">$<?= htmlspecialchars(number_format($row['harga'], 2)) ?></td>
                      </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            </div>

            <h3 class="text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Shipping Address</h3>
            <p class="text-white text-base font-normal leading-normal pb-3 pt-1 px-4"><?= htmlspecialchars($order['alamat_pengiriman'] ?? '-') ?></p>

            <h3 class="text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Payment Method</h3>
            <p class="text-white text-base font-normal leading-normal pb-3 pt-1 px-4"><?= htmlspecialchars($order['metode_pembayaran'] ?? '-') ?></p>

            <h3 class="text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Order Total</h3>
            <div class="p-4 grid grid-cols-[20%_1fr] gap-x-6">
              <div class="col-span-2 grid grid-cols-subgrid border-t border-t-[#3b4b54] py-5">
                <p class="text-[#9db0b9] text-sm font-normal leading-normal">Total</p>
                <p class="text-white text-sm font-normal leading-normal">$<?= htmlspecialchars(number_format($order['total'] ?? 0, 2)) ?></p>
              </div>
            </div>

            <h3 class="text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Order Status</h3>
            <p class="text-white text-base font-normal leading-normal pb-3 pt-1 px-4"><?= htmlspecialchars($order['status'] ?? '-') ?></p>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
