<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'koneksi.php'; 
session_start();

$message = ""; 
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? ''; 

    // Perbaikan: sesuaikan kolom dengan database
    $sql = "SELECT id, username, password, role FROM users WHERE email = ?";

    if (isset($conn) && $stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            // Perbaikan: dukung password hash dan plaintext (admin lama)
            if ($password === $row['password'] || password_verify($password, $row['password'])) {
                $_SESSION['id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['role'] = $row['role']; 

                // Redirect sesuai role
                if ($row['role'] === 'admin') {
                    header("Location: admin/dashboardadmin.php");
                } else {
                    header("Location: user/index.php");
                }
                exit;
            } else {
                $message = "Password salah.";
            }
        } else {
            $message = "Email tidak ditemukan.";
        }
        mysqli_stmt_close($stmt);
    } else {
        $message = "Error database. Cek file koneksi.php atau query SQL.";
    }
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />
    <title>TumbasBuku | Login User</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <style>
      .form-input:focus {
        border-color: #1193d4 !important;
        box-shadow: 0 0 0 1px #1193d4 !important;
      }
    </style>
        <?php
include "layout/topbar.php";
?>
        
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 flex-1 items-center">
            <h2 class="text-white tracking-light text-[28px] font-bold leading-tight px-4 text-center pb-3 pt-5">Selamat Datang Di TumbasBuku </h2>
            
            <form method="POST" action="" class="w-full max-w-[480px]">

                <?php if ($message): ?>
                    <p class="text-red-500 text-sm font-medium leading-normal pb-3 pt-1 px-4 text-center">
                        <?php echo htmlspecialchars($message); ?>
                    </p>
                <?php endif; ?>

                <div class="flex flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <p class="text-white text-base font-medium leading-normal pb-2">Email</p>
                        <input
                            type="email"
                            name="email" 
                            placeholder="Enter your email"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border-none bg-[#283339] focus:border-none h-14 placeholder:text-[#9db0b9] p-4 text-base font-normal leading-normal"
                            value="<?= htmlspecialchars($email) ?>"
                            required
                        />
                    </label>
                </div>
                
                <div class="flex flex-wrap items-end gap-4 px-4 py-3">
                    <label class="flex flex-col min-w-40 flex-1">
                        <p class="text-white text-base font-medium leading-normal pb-2">Password</p>
                        <input
                            type="password"
                            name="password"
                            placeholder="Enter your password"
                            class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border-none bg-[#283339] focus:border-none h-14 placeholder:text-[#9db0b9] p-4 text-base font-normal leading-normal"
                            required
                        />
                    </label>
                </div>
            
                <a href="lupapasword.php" class="text-[#1193d4] underline hover:text-blue-400">Lupa Password ? </a>

                <div class="flex px-4 py-3">
                    <button
                        type="submit"
                        class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 flex-1 bg-[#1193d4] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#0e7abf] transition-colors"
                    >
                        <span class="truncate">Log in</span>
                    </button>
                </div>
            </form>

            <p class="text-white text-sm font-normal leading-normal pt-4">
                Belum punya akun? 
                <a href="register.php" class="text-[#1193d4] underline hover:text-blue-400">Daftar sekarang</a>
            </p>

          </div>
        </div>
      </div>
    </div>
  </body>
</html>
