<?php
include '../koneksi.php';

// =========================================================
// 2. LOGIKA FILTER KATEGORI
// =========================================================
$selected_categories = [];
if (isset($_GET['kategori'])) {
    $kategori_input = $_GET['kategori'];
    if (is_array($kategori_input)) {
        foreach ($kategori_input as $k_id) {
            $selected_categories[] = (int) $k_id;
        }
    } elseif (is_numeric($kategori_input)) {
        $selected_categories[] = (int) $kategori_input;
    }
}

// =========================================================
// 3. AMBIL DATA KATEGORI (Untuk Sidebar Filter)
// =========================================================
$kategori_data = [];
$result_kategori = mysqli_query($conn, "SELECT id, nama_kategori FROM kategori ORDER BY nama_kategori ASC");
if ($result_kategori) {
    while ($row = mysqli_fetch_assoc($result_kategori)) {
        $kategori_data[] = $row;
    }
}

// =========================================================
// 4. AMBIL DATA BUKU (TERMASUK ID dan URL)
// =========================================================
$buku_data = [];
$sql_buku = "SELECT b.id, b.judul, b.penulis, b.url, k.nama_kategori 
             FROM buku b 
             JOIN kategori k ON b.kategori_id = k.id";

if (!empty($selected_categories)) {
    $placeholders = implode(',', array_fill(0, count($selected_categories), '?'));
    $sql_buku .= " WHERE b.kategori_id IN ($placeholders)";
    
    $stmt_buku = mysqli_prepare($conn, $sql_buku);
    $types = str_repeat('i', count($selected_categories));
    mysqli_stmt_bind_param($stmt_buku, $types, ...$selected_categories);
    mysqli_stmt_execute($stmt_buku);
    $result_buku = mysqli_stmt_get_result($stmt_buku);
} else {
    $result_buku = mysqli_query($conn, $sql_buku);
}

if ($result_buku) {
    while ($row = mysqli_fetch_assoc($result_buku)) {
        $buku_data[] = $row;
    }
}

if (isset($stmt_buku)) {
    mysqli_stmt_close($stmt_buku);
}
mysqli_close($conn);

// =========================================================
// 5. FUNGSI MEMBANGUN URL FILTER
// =========================================================
function build_category_url($current_categories, $toggle_id) {
    $new_categories = $current_categories;
    $key = array_search($toggle_id, $new_categories);

    if ($key !== false) {
        unset($new_categories[$key]);
    } else {
        $new_categories[] = $toggle_id;
    }

    $query_params = [];
    if (!empty($new_categories)) {
        foreach (array_values($new_categories) as $id) {
            $query_params[] = "kategori[]=" . $id;
        }
    }
    
    return "?" . implode("&", $query_params);
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
<meta charset="utf-8"/>
<title>TumbasBuku | Kategori Buku</title>
<link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,"/>
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin/>
<link as="style" onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&family=Noto+Sans:wght@400;500;700;900&family=Work+Sans:wght@400;500;700;900"
      rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<script>
tailwind.config = {
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        "primary": "#1193d4",
        "background-dark": "#111618",
      },
      fontFamily: { "display": ["Work Sans"] },
    },
  },
}
</script>
</head>

<body class="font-display bg-background-dark text-slate-200">

  <!-- ✅ TOPBAR -->
  <?php include "../layout/topbaruser.php"; ?>

  <!-- ✅ KONTEN (diberi jarak dari topbar agar tidak ketimpa) -->
  <div class="flex flex-1 pt-20"> <!-- 🔥 Tambah padding-top di sini -->

    <!-- SIDEBAR KATEGORI -->
    <aside class="w-80 border-r border-slate-800 bg-[#1a1f22] p-6">
      <h3 class="text-lg font-bold text-white mb-4">Kategori Buku</h3>
      <div class="space-y-1">
        <?php foreach ($kategori_data as $kategori): 
          $is_selected = in_array($kategori['id'], $selected_categories);
          $link_url = build_category_url($selected_categories, $kategori['id']);
        ?>
        <a href="<?= $link_url ?>"
           class="flex items-center gap-3 rounded-lg px-3 py-2 transition-all 
                  <?= $is_selected ? 'bg-primary/20' : 'hover:bg-[#22282c]' ?>">
          <input type="checkbox"
                 class="h-5 w-5 rounded border-slate-600 bg-transparent text-primary 
                        checked:bg-primary checked:border-primary focus:ring-0"
                 <?= $is_selected ? 'checked' : '' ?>
                 onclick="window.location.href='<?= $link_url ?>';">
          <span class="text-sm font-medium <?= $is_selected ? 'text-primary' : 'text-gray-300' ?>">
            <?= htmlspecialchars($kategori['nama_kategori']) ?>
          </span>
        </a>
        <?php endforeach; ?>
      </div>
    </aside>

    <!-- KONTEN UTAMA -->
    <main class="flex-1 p-8 bg-[#111618]">
      <div class="flex items-center justify-between pb-6">
        <h1 class="text-3xl font-bold text-white">Jelajahi Buku</h1>
      </div>

      <div class="grid grid-cols-[repeat(auto-fill,minmax(160px,1fr))] gap-6">
        <?php if (empty($buku_data)): ?>
          <p class="text-slate-400 col-span-full text-center">
            Tidak ada buku yang ditemukan untuk kriteria ini.
          </p>
        <?php else: ?>
          <?php foreach ($buku_data as $buku): ?>
            <a href="bookdetail.php?id=<?= htmlspecialchars($buku['id']) ?>" class="group block">
              <div class="overflow-hidden rounded-lg">
                <div class="w-full aspect-[3/4] bg-cover bg-center bg-no-repeat transition-transform duration-300 group-hover:scale-105"
                     style='background-image: url("<?= htmlspecialchars($buku['url']) ?>");'>
                </div>
              </div>
              <div class="pt-3">
                <p class="text-base font-medium text-white"><?= htmlspecialchars($buku['judul']) ?></p>
                <p class="text-sm text-slate-400"><?= htmlspecialchars($buku['penulis']) ?></p>
              </div>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </main>

  </div>
</div>
</body>
</html>
