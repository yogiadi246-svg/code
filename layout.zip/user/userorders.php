<?php

session_set_cookie_params(['path' => '/']);
session_start();

// Pastikan user sudah login
include '../koneksi.php'; // koneksi ke database
$user_id = $_SESSION['id'];

// Ambil data transaksi user
$sql = "SELECT id, tanggal, total, status FROM transaksi WHERE user_id = ? ORDER BY tanggal DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}
$stmt->close();
$conn->close();
?>

<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />
    <title>NovelNest | My Orders</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>

  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
                       <?php include "../layout/topbaruser.php"; ?>


        <!-- ✅ KONTEN -->
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">
            <div class="flex flex-wrap justify-between gap-3 p-4">
              <p class="text-white tracking-light text-[32px] font-bold leading-tight min-w-72">My Orders</p>
            </div>

            <div class="px-4 py-3 @container">
              <div class="flex overflow-hidden rounded-lg border border-[#3b4b54] bg-[#111618]">
                <table class="flex-1">
                  <thead>
                    <tr class="bg-[#1c2327]">
                      <th class="px-4 py-3 text-left text-white text-sm font-medium leading-normal w-[400px]">Order Number</th>
                      <th class="px-4 py-3 text-left text-white text-sm font-medium leading-normal w-[400px]">Date</th>
                      <th class="px-4 py-3 text-left text-white text-sm font-medium leading-normal w-[400px]">Total</th>
                      <th class="px-4 py-3 text-left text-white text-sm font-medium leading-normal w-60">Status</th>
                      <th class="px-4 py-3 text-left text-[#9db0b9] text-sm font-medium leading-normal w-60">Actions</th>
                    </tr>
                  </thead>

                  <tbody>
                    <?php if (empty($orders)): ?>
                      <tr class="border-t border-t-[#3b4b54]">
                        <td colspan="5" class="text-center text-[#9db0b9] py-6">
                          Tidak ada pesanan yang ditemukan.
                        </td>
                      </tr>
                    <?php else: ?>
                      <?php foreach ($orders as $order): ?>
                        <tr class="border-t border-t-[#3b4b54]">
                          <td class="h-[72px] px-4 py-2 text-white text-sm font-normal leading-normal">#<?= htmlspecialchars($order['id']) ?></td>
                          <td class="h-[72px] px-4 py-2 text-[#9db0b9] text-sm font-normal leading-normal"><?= date('F j, Y', strtotime($order['tanggal'])) ?></td>
                          <td class="h-[72px] px-4 py-2 text-[#9db0b9] text-sm font-normal leading-normal">Rp <?= number_format($order['total'], 0, ',', '.') ?></td>
                          <td class="h-[72px] px-4 py-2 text-sm font-normal leading-normal">
                            <button class="flex items-center justify-center rounded-lg h-8 px-4 bg-[#283339] text-white text-sm font-medium leading-normal w-full">
                              <span class="truncate"><?= ucfirst($order['status']) ?></span>
                            </button>
                          </td>
                          <td class="h-[72px] px-4 py-2 text-[#9db0b9] text-sm font-bold leading-normal tracking-[0.015em]">
                            <a href="viewtransaksi.php?id=<?= $order['id'] ?>" class="hover:text-white">View Details</a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
