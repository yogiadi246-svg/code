<?php
// =========================================================
// 1. KONEKSI DATABASE
// =========================================================
include '../koneksi.php';
session_start();

// Pastikan variabel koneksi aktif ($koneksi atau $conn)
$db = null;
if (isset($koneksi) && $koneksi instanceof mysqli) {
    $db = $koneksi;
} elseif (isset($conn) && $conn instanceof mysqli) {
    $db = $conn;
} else {
    die("Koneksi database gagal: variabel koneksi tidak ditemukan di koneksi.php");
}

// =========================================================
// 2. PROSES FORM KONTAK
// =========================================================
$success_message = $error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = trim($_POST['id'] ?? '');
    $email = trim($_POST['user_id'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $pesan = trim($_POST['message'] ?? '');

    if ($nama && $email && $subject && $pesan) {
        // Siapkan dan eksekusi query insert
        $stmt = $db->prepare("INSERT INTO kontak (id, user_id, subject, message, tanggal) VALUES (?, ?, ?, ?, NOW())");
        if ($stmt) {
            $stmt->bind_param("ssss", $nama, $email, $subject, $pesan);
            if ($stmt->execute()) {
                $success_message = "Pesan Anda berhasil dikirim. Terima kasih telah menghubungi kami!";
            } else {
                $error_message = "Gagal mengirim pesan. Silakan coba lagi.";
            }
            $stmt->close();
        } else {
            $error_message = "Terjadi kesalahan pada server.";
        }
    } else {
        $error_message = "Semua kolom wajib diisi.";
    }
}
?>

<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />
    <title>TumbasBuku | Contact Admin</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>

  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden"
         style='font-family: "Work Sans", "Noto Sans", sans-serif;'>

      <div class="layout-container flex h-full grow flex-col">

                <?php include "../layout/topbaruser.php"; ?>


        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">

            <?php if ($success_message): ?>
              <div class="bg-green-600 text-white p-3 rounded-lg mb-4 text-center">
                <?= htmlspecialchars($success_message) ?>
              </div>
            <?php elseif ($error_message): ?>
              <div class="bg-red-600 text-white p-3 rounded-lg mb-4 text-center">
                <?= htmlspecialchars($error_message) ?>
              </div>
            <?php endif; ?>

            <div class="flex flex-wrap justify-between gap-3 p-4">
              <div class="flex min-w-72 flex-col gap-3">
                <p class="text-white tracking-light text-[32px] font-bold leading-tight">Contact Us</p>
                <p class="text-[#9db0b9] text-sm font-normal leading-normal">
                  We'd love to hear from you! Please fill out the form below and we'll get back to you as soon as possible.
                </p>
              </div>
            </div>

            <!-- FORM KONTAK -->
            <form method="POST" action="">
              <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                
              </div>

              <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                <label class="flex flex-col min-w-40 flex-1">
                  <p class="text-white text-base font-medium leading-normal pb-2">Subject</p>
                  <input name="subject" placeholder="Subject" required
                    class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white 
                           focus:outline-0 focus:ring-0 border-none bg-[#283339] focus:border-none h-14 
                           placeholder:text-[#9db0b9] p-4 text-base font-normal leading-normal"/>
                </label>
              </div>

              <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                <label class="flex flex-col min-w-40 flex-1">
                  <p class="text-white text-base font-medium leading-normal pb-2">Message</p>
                  <textarea name="pesan" placeholder="Your Message" required
                    class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white 
                           focus:outline-0 focus:ring-0 border-none bg-[#283339] focus:border-none min-h-36 
                           placeholder:text-[#9db0b9] p-4 text-base font-normal leading-normal"></textarea>
                </label>
              </div>

              <div class="flex px-4 py-3 justify-end">
                <button type="submit"
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden 
                         rounded-lg h-10 px-4 bg-[#1193d4] text-white text-sm font-bold leading-normal tracking-[0.015em]">
                  <span class="truncate">Send Message</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </body>
</html>
