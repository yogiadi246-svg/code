<?php
include '../koneksi.php'; // pastikan koneksi benar
session_start();

// Ambil ID buku dari URL (contoh: detail_buku.php?id=3)
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Query ambil data buku dari database
$query = "SELECT * FROM buku WHERE id = $id LIMIT 1";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
  $buku = $result->fetch_assoc();
} else {
  // Jika buku tidak ditemukan
  $buku = [
    'judul' => 'Buku Tidak Ditemukan',
    'penulis' => '-',
    'deskripsi' => 'Data buku tidak tersedia di database.',
    'harga' => '0',
    'url' => 'https://via.placeholder.com/400x600?text=No+Image'
  ];
}
?>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Work+Sans%3Awght%40400%3B500%3B700%3B900"
    />

    <title><?= htmlspecialchars($buku['judul']) ?> | NovelNest</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
                       <?php
include "../layout/topbaruser.php";
?>
        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col max-w-[960px] flex-1">
            <div class="flex flex-wrap gap-2 p-4">
              <a class="text-[#9db0b9] text-base font-medium leading-normal" href="index.php">Books</a>
              <span class="text-[#9db0b9] text-base font-medium leading-normal">/</span>
              <span class="text-white text-base font-medium leading-normal"><?= htmlspecialchars($buku['judul']) ?></span>
            </div>

            <div class="p-4 @container">
              <div class="flex flex-col items-stretch justify-start rounded-lg @xl:flex-row @xl:items-start">
                <div
                  class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-lg"
                  style='background-image: url("<?= htmlspecialchars($buku['url']) ?>");'
                ></div>
                <div class="flex w-full min-w-72 grow flex-col items-stretch justify-center gap-1 py-4 @xl:px-4">
                  <p class="text-white text-lg font-bold leading-tight tracking-[-0.015em]"><?= htmlspecialchars($buku['judul']) ?></p>
                  <div class="flex items-end gap-3 justify-between">
                    <div class="flex flex-col gap-1">
                      <p class="text-[#9db0b9] text-base font-normal leading-normal"><?= htmlspecialchars($buku['deskripsi']) ?></p>
                      <p class="text-[#9db0b9] text-base font-normal leading-normal">By <?= htmlspecialchars($buku['penulis']) ?></p>
                    </div>
                    <button
                      class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-8 px-4 bg-[#1193d4] text-white text-sm font-medium leading-normal"
                    >
                      <span class="truncate">Rp<?= number_format($buku['harga'], 0, ',', '.') ?></span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div class="flex px-4 py-3 justify-start">
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#1193d4] text-white text-sm font-bold leading-normal tracking-[0.015em]"
              >
                <span class="truncate">Add to Cart</span>
              </button>
            </div>

            <h2 class="text-white text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">About the Book</h2>
            <p class="text-white text-base font-normal leading-normal pb-3 pt-1 px-4">
              <?= nl2br(htmlspecialchars($buku['deskripsi'])) ?>
            </p>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
