<?php
session_start();

// Hapus semua data sesi
$_SESSION = [];

// Hancurkan sesi sepenuhnya
session_destroy();

// Opsional: hapus cookie sesi agar benar-benar bersih
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Arahkan ke halaman login atau home
header("Location: login.php");
exit;
?>
