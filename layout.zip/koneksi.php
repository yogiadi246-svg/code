<?php
// koneksi.php

$host = "localhost"; 
$user = "root"; 
$pass = ""; 
$db_name = "book_store"; // Pastikan nama database sudah benar

// Mencoba koneksi
$conn = mysqli_connect($host, $user, $pass, $db_name);

// Cek koneksi. Jika gagal, hentikan script dan tampilkan error detail.
if (mysqli_connect_errno()) {
    die("Koneksi database GAGAL: " . mysqli_connect_error());
}
?>