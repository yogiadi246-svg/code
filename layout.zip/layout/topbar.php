</head>
  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
        <header class="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#283339] px-10 py-3">
          <div class="flex items-center gap-4 text-white">
            <div class="size-4">
            </div>
            <h2 class="text-white text-lg font-bold leading-tight tracking-[-0.015em]">TumbasBuku</h2>
          </div>
          </div>
        </header>