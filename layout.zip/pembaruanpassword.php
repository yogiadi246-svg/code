<?php
// reset_password.php

// Pastikan file koneksi tersedia dan koneksi disimpan di $conn
include 'koneksi.php'; 
session_start();

// Aktifkan pelaporan error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Variabel untuk status dan input
$message = ""; 
$new_password = '';
$confirm_password = '';
$password_updated = false; // Flag baru untuk status sukses

// Cek apakah ada sesi reset yang valid (dari forgot_password.php)
if (!isset($_SESSION['reset_email'])) {
    // Jika sesi tidak ada (mungkin user langsung akses halaman ini)
    $message = "Akses tidak sah. Silakan mulai ulang proses lupa password dari awal.";
    $is_valid_session = false;
} else {
    $is_valid_session = true;
    $reset_email = $_SESSION['reset_email'];
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // 1. Ambil data dari form
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // 2. Validasi input
        if (empty($new_password) || empty($confirm_password)) {
            $message = "Semua kolom password wajib diisi.";
        } elseif ($new_password !== $confirm_password) {
            $message = "Password baru dan konfirmasi tidak cocok.";
        } elseif (strlen($new_password) < 6) {
            $message = "Password baru minimal 6 karakter.";
        } else {
            // 3. Verifikasi berhasil, lakukan update password
            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            // KOREKSI UTAMA: Mengganti 'password_hash' menjadi 'password'
            $update_sql = "UPDATE users SET password = ? WHERE email = ?"; 
            
            if ($stmt = mysqli_prepare($conn, $update_sql)) {
                mysqli_stmt_bind_param($stmt, "ss", $password_hash, $reset_email);
                
                if (mysqli_stmt_execute($stmt)) {
                    // Update berhasil, bersihkan sesi reset
                    unset($_SESSION['reset_email']);
                    unset($_SESSION['reset_code']); 
                    
                    // JANGAN REDIRECT. Tetapkan di halaman yang sama.
                    $password_updated = true; 
                    $message = "Password Anda berhasil diperbarui! Silakan kembali ke halaman login.";
                } else {
                    $message = "Gagal memperbarui password: " . mysqli_error($conn);
                }
                mysqli_stmt_close($stmt);
            } else {
                $message = "Error database. Silakan coba lagi.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght@400;500;700;900&amp;family=Work+Sans%3Awght@400;500;700;900"
    />
    <title>NovelNest | Set New Password</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <style>
      /* Memperbaiki input agar sesuai tema gelap */
      .form-input {
        background-color: #283339 !important; 
        color: #fff !important; 
        border: none !important;
      }
      .form-input:focus {
        border-color: #1193d4 !important; 
        box-shadow: 0 0 0 1px #1193d4 !important;
      }
    </style>
  </head>
  <body>
    <div class="relative flex h-auto min-h-screen w-full flex-col bg-[#111618] dark group/design-root overflow-x-hidden" style='font-family: "Work Sans", "Noto Sans", sans-serif;'>
      <div class="layout-container flex h-full grow flex-col">
        
        <header class="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#283339] px-10 py-3">
            <div class="flex items-center gap-4 text-white">
                <div class="size-4">
                  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor"></path></svg>
                </div>
                <h2 class="text-white text-lg font-bold leading-tight tracking-[-0.015em]">NovelNest</h2>
            </div>
            <div class="flex flex-1 justify-end gap-8">
                <div class="flex items-center gap-9">
                  <a class="text-white text-sm font-medium leading-normal" href="#">Home</a>
                  <a class="text-white text-sm font-medium leading-normal" href="#">Shop</a>
                  <a class="text-white text-sm font-medium leading-normal" href="#">About</a>
                  <a class="text-white text-sm font-medium leading-normal" href="#">Contact</a>
                </div>
                <a href="login.php" class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#283339] text-white text-sm font-bold leading-normal tracking-[0.015em]">
                  <span class="truncate">Sign In</span>
                </a>
            </div>
        </header>

        <div class="px-40 flex flex-1 justify-center py-5">
          <div class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 flex-1 items-center">
            
            <?php if ($message): ?>
                <p class="text-<?= ($password_updated) ? 'green-400' : 'red-500' ?> text-sm font-medium leading-normal pb-3 pt-1 px-4 text-center">
                    <?php echo htmlspecialchars($message); ?>
                </p>
            <?php endif; ?>

            <?php if ($is_valid_session && !$password_updated): // Tampilkan form jika sesi valid dan belum sukses ?>
            
                <h2 class="text-white tracking-light text-[28px] font-bold leading-tight px-4 text-center pb-3 pt-5">Perbarui password</h2>
                <p class="text-white text-base font-normal leading-normal pb-3 pt-1 px-4 text-center">Masukkan password baru kamu dan confirm password.</p>
                
                <form method="POST" action="" class="w-full max-w-[480px]">
                    <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                        <label class="flex flex-col min-w-40 flex-1">
                            <input
                                type="password"
                                name="new_password"
                                placeholder="New Password"
                                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 h-14 placeholder:text-[#9db0b9] p-4 text-base font-normal leading-normal"
                                required
                            />
                        </label>
                    </div>

                    <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                        <label class="flex flex-col min-w-40 flex-1">
                            <input
                                type="password"
                                name="confirm_password"
                                placeholder="Confirm New Password"
                                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 h-14 placeholder:text-[#9db0b9] p-4 text-base font-normal leading-normal"
                                required
                            />
                        </label>
                    </div>

                    <div class="flex px-4 py-3 justify-center">
                        <button
                            type="submit"
                            class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#1193d4] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#0e7abf] transition-colors"
                        >
                            <span class="truncate">Reset Password</span>
                        </button>
                    </div>
                </form>
                
            <?php elseif ($password_updated): // Tampilkan pesan sukses jika password sudah diupdate ?>
            
                <h2 class="text-white tracking-light text-[28px] font-bold leading-tight px-4 text-center pb-3 pt-5">Password Berhasil Diperbarui! 🎉</h2>
                <p class="text-white text-base font-normal leading-normal pb-3 pt-1 px-4 text-center">Password Anda telah berhasil diubah. Silakan kembali ke halaman login.</p>
                
                <div class="flex px-4 py-3 justify-center">
                    <a href="login.php"
                        class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 flex-1 bg-[#283339] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#1c2327] transition-colors"
                    >
                        <span class="truncate">Login Sekarang</span>
                    </a>
                </div>
            
            <?php endif; ?>
            
          </div>
        </div>
      </div>
    </div>
  </body>
</html>